package com.agresta.CareerTrack.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpServletRequest;

@Controller
public class LoginController {

	@PostConstruct
	public void init() {
		System.out.println(">>>> LoginController Loaded!");
	}
	
	@GetMapping("/login")
	public String login(HttpServletRequest req) {
	    System.out.println(">>> LoginController: request path = " + req.getRequestURI());
	    return "login";
	}

//    @GetMapping("/login")
//    public String login() {
//        return "login";
//    }
}
